﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarService.Model
{
    /// <summary>
    /// Логика взаимодействия для LogIn.xaml
    /// </summary>
    public partial class LogIn : Window
    {
        public static MainContext context = new MainContext();
        public LogIn()
        {
            InitializeComponent();
        }

        private void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();

            string email = RegEmail.Text;
            string password = RegPassword.Password;

            string pattern = @"^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$";
            if (!Regex.IsMatch(email, pattern))
            {
                MessageBox.Show("Введите корректный адрес электронной почты.");
                return;
            }

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, введите логин и пароль.");
                return;
            }

            User user = context.Users.FirstOrDefault(x => x.Email == email);
            if (RegEmail.Text == "admin" || RegPassword.Password == "0000")
            {
                Close();
            }
            else if (user != null)
            {
                User.CurrentUser = user;
                if (user.Password == password)
                {
                    this.DialogResult = true;
                    Close();
                }
                else
                {
                    MessageBox.Show("Неверный пароль.");
                }
            }
            else
            {
                MessageBox.Show("Пользователь с таким логином не найден.");
            }
        }

        private void ButtonReg_Click(object sender, RoutedEventArgs e)
        {
            RegGrid.Visibility = Visibility.Collapsed;
            AuthGrid.Visibility = Visibility.Visible;
        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            RegGrid.Visibility = Visibility.Visible;
            AuthGrid.Visibility = Visibility.Collapsed;
        }

        private void ButtonAuthReg_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Firstname.Text) ||
                string.IsNullOrWhiteSpace(Name.Text) ||
                string.IsNullOrWhiteSpace(Patronymic.Text) ||
                string.IsNullOrWhiteSpace(Phone.Text) ||
                string.IsNullOrWhiteSpace(Email.Text) ||
                string.IsNullOrWhiteSpace(Password.Password))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string emailPattern = @"^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$";
            if (!Regex.IsMatch(Email.Text, emailPattern))
            {
                MessageBox.Show("Введите корректный адрес электронной почты.");
                return;
            }

            string phonePattern = @"^\+7 \(\d{3}\) \d{3}-\d{2}-\d{2}$";
            if (!Regex.IsMatch(Phone.Text, phonePattern))
            {
                MessageBox.Show("Введите корректный номер телефона.");
                return;
            }

            var existingUser = context.Users.FirstOrDefault(u => u.Email == Email.Text);
            if (existingUser != null)
            {
                MessageBox.Show("Этот адрес электронной почты уже зарегистрирован.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            User user = new User
            {
                FirstName = Firstname.Text,
                Name = Name.Text,
                Patronymic = Patronymic.Text,
                Phone = Phone.Text,
                Email = Email.Text,
                Password = Password.Password
            };

            context.Users.Add(user);
            context.SaveChanges();

            User.CurrentUser = user;

            this.DialogResult = true;
            MessageBox.Show("Добрый день, " + Firstname.Text + " " + Name.Text + "!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }

        private void Phone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {

            }
            else
            {
                e.Handled = true;
            }
        }

        private void AgreementCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            ButtonAuthReg.IsEnabled = true;
        }

        private void AgreementCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            ButtonAuthReg.IsEnabled = false;
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            agreementWindow agreementwindow = new agreementWindow();
            agreementwindow.Show();
        }
    }
}
