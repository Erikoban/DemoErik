﻿using CarService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarService
{
    /// <summary>
    /// Логика взаимодействия для ClientRecord.xaml
    /// </summary>
    public partial class ClientRecord : Window
    {
        public static MainContext context = new MainContext();

        public ClientRecord(Service btn)
        {
            InitializeComponent();
            DataContext = btn;

            datePicker.DisplayDateStart = DateTime.Now;
        }

        private void Record_Click(object sender, RoutedEventArgs e)
        {
            DateTime date = datePicker.SelectedDate ?? DateTime.Today;
            int hour = (int)numericHour.Value;
            int minute = (int)numericMin.Value;
            DateTime dateTime = new DateTime(date.Year, date.Month, date.Day, hour, minute, 0);
            DateTime currentDateTime = DateTime.Now;

            if (dateTime >= currentDateTime)
            {
                var existingBooking = context.ServicesBooking
                    .FirstOrDefault(b => b.DateTime == dateTime && b.ServiceId == Convert.ToInt32(ID.Text));

                if (existingBooking != null)
                {
                    MessageBox.Show("На это время уже есть запись!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                ServiceBooking serviceBooking = new ServiceBooking
                {
                    ServiceId = Convert.ToInt32(ID.Text),
                    UserId = User.CurrentUser.Id,
                    DateTime = dateTime
                };

                context.ServicesBooking.Add(serviceBooking);
                context.SaveChanges();
                MessageBoxResult result = MessageBox.Show("Вы записаны на улсугу!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Нельзя ввести прошедшее время!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void datePicker_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9 || e.Key >= Key.A && e.Key <= Key.Z)
            {
                e.Handled = true;
            }

        }
    }
}
