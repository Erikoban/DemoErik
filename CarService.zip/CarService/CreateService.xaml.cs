﻿using CarService.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarService
{
    /// <summary>
    /// Логика взаимодействия для CreateServcie.xaml
    /// </summary>
    public partial class CreateService : Window
    {
        MainWindow main = new MainWindow();
        public static MainContext context = new MainContext();

        public CreateService(Service btn)
        {
            InitializeComponent();
            DataContext = btn;
        }

        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Добавить новую услугу?", "Сообщение", MessageBoxButton.YesNo, MessageBoxImage.Asterisk);
            if (result == MessageBoxResult.Yes)
            {

                var unique = main.fullList.Count(x => x.Name.Contains(NewNameService.Text));


                if (NewNameService.Text == "" || NewCost.Text == "" || NewDiscount.Text == "" || mainImage.Source == null)
                {
                    result = MessageBox.Show("Остались пустые поля или не выбрана картинка", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (unique != 0)
                {
                    result = MessageBox.Show("Назание услуги уже занято", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (NewDescription.Text.Length >= 1000)
                {
                    result = MessageBox.Show("Кол-во символов не может быть больше 1000", "Ошибка сохранения", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (Convert.ToInt32(NewCost.Text) < 0 || Convert.ToInt32(NewCost.Text) > 100000000 || Convert.ToInt32(NewDiscount.Text) < 0 || Convert.ToInt32(NewDiscount.Text) > 100)
                {
                    result = MessageBox.Show("Нельзя использовать отрицательные значения, скидку больше 100% или стоимость услуги больше 100млн", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    Service service1 = new Service { Name = NewNameService.Text, Description = NewDescription.Text, Price = Convert.ToInt32(NewCost.Text), Discount = Convert.ToInt32(NewDiscount.Text), Picture = mainImage.Source.ToString() };

                    context.Services.Add(service1);

                    context.SaveChanges();
                    main.lists.Clear();
                    var services = context.Services.ToList();
                    foreach (var item in services)
                    {
                        main.lists.Add(item);
                    }

                    this.DialogResult = true;
                    MessageBox.Show("Новая услуга создана", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.Close();
                }
            }
        }

        private void AddImage_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.Filter = "All Files (*.*)|*.*|JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                string filename = System.IO.Path.GetFileNameWithoutExtension(dlg.FileName);
                string extension = System.IO.Path.GetExtension(dlg.FileName);
                string file = filename + "_" + DateTime.Now.Ticks + extension;
                string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Image\\");

                if (!System.IO.Directory.Exists(path))
                {
                    System.IO.Directory.CreateDirectory(path);
                }

                System.IO.File.Copy(dlg.FileName.Replace("\\", "/"), path + file);

                mainImage.Source = new BitmapImage(new Uri(path + file));
            }
        }

        private void NewNameService_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void NewDescription_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void NewCost_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox.Text.Length >= 6)
            {
                e.Handled = true;
            }
            else if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {

            }
            else
            {
                e.Handled = true;
            }
        }

        private void NewDuration_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {

            }
            else
            {
                e.Handled = true;
            }
        }

        private void NewDiscount_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox.Text.Length >= 2)
            {
                e.Handled = true;
            }
            else if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {

            }
            else
            {
                e.Handled = true;
            }
        }

        private void NewDiscount_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void NewNameService_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox.Text.Length >= 25) 
            {
                e.Handled = true;
            }
        }

        private void NewDescription_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox.Text.Length >= 100)
            {
                e.Handled = true;
            }
        }
    }
}
