﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace CarService.Model
{
    public class Service
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public double? Discount { get; set; }
        public string? Picture { get; set; }

        public int? PriceInt => (int?)Price;
        public double? PriceDiscount => PriceInt - (PriceInt * Discount / 100);

        public List<ServiceBooking> ServiceBookings { get; set; }
    }
}
