﻿using System;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarService.Model
{
    public class MainContext : DbContext
    {
        private readonly string connectionString = "data source=192.168.221.12;initial catalog=CarService;persist security info=True;user id=user03;password=03;TrustServerCertificate=True;MultipleActiveResultSets=True;App=EntityFramework";

        //connectionString = "Data source=DESKTOP-J021N6I;Initial catalog=CarService;Trusted_Connection=True;MultipleActiveResultSets=True;TrustServerCertificate=True;encrypt=False"
        //connectionString = "data source=192.168.221.12;initial catalog=CarService;persist security info=True;user id=user03;password=03;TrustServerCertificate=True;MultipleActiveResultSets=True;App=EntityFramework"
        public MainContext()
        {
            Database.EnsureCreated();
        }
        public DbSet<User> Users { get; set; }
        public DbSet<Service> Services { get; set; }
        public DbSet<ServiceBooking> ServicesBooking { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(connectionString);
        }
    }
}
