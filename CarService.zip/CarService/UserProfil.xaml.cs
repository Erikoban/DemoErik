﻿using CarService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace CarService
{
    /// <summary>
    /// Логика взаимодействия для UserProfil.xaml
    /// </summary>
    public partial class UserProfil : Window
    {
        public static MainContext context = new MainContext();
        public UserProfil()
        {
            InitializeComponent();

            RefreshData();

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(30);
            timer.Tick += timer_Tick;
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            RefreshData();
        }
        private void RefreshData()
        {
            int currentUserId = User.CurrentUser.Id;
            string format = "dd.MM.yyyy HH:mm";
            var result = (from serviceBooking in context.ServicesBooking
                          join user in context.Users on serviceBooking.UserId equals user.Id
                          join service in context.Services on serviceBooking.ServiceId equals service.Id
                          where user.Id == currentUserId
                          select new
                          {
                              Service_name = service.Name,
                              DateTime = serviceBooking.DateTime.ToString(format),

                              DateTime1 = serviceBooking.DateTime,
                              Id = serviceBooking.Id,
                          }).Where(x => x.DateTime1 >= DateTime.Now).OrderBy(x => x.DateTime1).ToList();
            GridAdmin.ItemsSource = result;
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedServiceBooking = (dynamic)GridAdmin.SelectedItem;
            if (selectedServiceBooking != null)
            {
                var serviceBooking = context.ServicesBooking.Find(selectedServiceBooking.Id);
                if (serviceBooking != null)
                {
                    context.ServicesBooking.Remove(serviceBooking);
                    context.SaveChanges();
                    RefreshData();
                }
            }
        }
    }
}
