﻿using CarService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarService
{
    public partial class EditService : Window
    {
        MainWindow main = new MainWindow();
        public static MainContext context = new MainContext();

        public EditService(Service btn)
        {
            InitializeComponent();
            DataContext = btn;
        }

        private void EditImage_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.Filter = "All Files (*.*)|*.*|JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                string filename = System.IO.Path.GetFileNameWithoutExtension(dlg.FileName);
                string extension = System.IO.Path.GetExtension(dlg.FileName);
                string file = filename + "_" + DateTime.Now.Ticks + extension;
                string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Image\\");
                System.IO.File.Copy(dlg.FileName.Replace("\\", "/"), path + file);

                mainImage.Source = new BitmapImage(new Uri(path + file));
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Изменить услугу?", "Сообщение", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result == MessageBoxResult.Yes)
            {
                //var unique = main.fullList.Where(x => EF.Functions.Like(x.Service_name, NewNameService.Text)).Count();
                Service service = context.Services.Where(x => x.Id.ToString() == ID.Text).FirstOrDefault();
                if (NewNameService.Text != "" /*&& unique == 0*/)
                {
                    service.Name = NewNameService.Text;
                    if (NewDescription.Text.Length <= 1000)
                    {
                        service.Description = NewDescription.Text;

                        if (NewCost.Text != null)
                        {
                            try
                            {
                                service.Price = Convert.ToDecimal(NewCost.Text);
                            }
                            catch (Exception)
                            {
                                MessageBox.Show("Сохранение прошло успешно!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            if (NewDiscount.Text != null && Convert.ToInt32(NewDiscount.Text) >= 0 && Convert.ToInt32(NewDiscount.Text) <= 100)
                            {
                                service.Discount = Convert.ToInt32(NewDiscount.Text);
                                if (mainImage.Source != null)
                                {
                                    service.Picture = mainImage.Source.ToString();
                                    //ServicePhoto servicePhoto = context.ServicePhotoes.Where

                                    context.SaveChanges();
                                    main.lists.Clear();
                                    var services = context.Services.ToList();
                                    foreach (var item in services)
                                    {
                                        main.lists.Add(item);
                                    }

                                    this.DialogResult = true;
                                    this.Close();
                                }
                                else
                                    MessageBox.Show("Нет изображения!", "Ошибка сохранения!", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                                MessageBox.Show("Заполните поле 'Скидка', кол-во символов должно быть больше 0 и меньше 100!", "Ошибка сохранения!", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                            MessageBox.Show("Заполните поле 'Стоимость', кол-во символов быть больше 0 и меньше 2147483647!", "Ошибка сохранения!", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                        MessageBox.Show("В описании кол-во символов должно быть меньше 1000!", "Ошибка сохранения!", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                    MessageBox.Show("Поле 'Название' занято или пусто!", "Ошибка сохранения!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void NewCost_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox.Text.Length >= 6)
            {
                e.Handled = true;
            }
            else if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {

            }
            else
            {
                e.Handled = true;
            }
        }

        private void NewDiscount_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox.Text.Length >= 2)
            {
                e.Handled = true;
            }
            else if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {

            }
            else
            {
                e.Handled = true;
            }
        }

        private void NewNameService_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox.Text.Length >= 25)
            {
                e.Handled = true;
            }
        }

        private void NewDescription_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox.Text.Length >= 100)
            {
                e.Handled = true;
            }
        }
    }
}
