﻿using CarService.Model;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.Metrics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarService
{
    public partial class MainWindow : Window
    {
        MainContext context = new MainContext();
        public ObservableCollection<Service> lists { get; set; }
        public List<Service> fullList { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            fullList = context.Services.ToList();
            lists = new ObservableCollection<Service>(fullList);

            services.ItemsSource = lists;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            LogIn logIn = new LogIn();

            var checkAdmin = logIn.ShowDialog();

            if (logIn.RegPassword.Password == "0000")
            {
                this.Title = "Admin";
            }

            if (checkAdmin == true)
            {
                this.Title = "User";

                LogInUser.Visibility = Visibility.Collapsed;
                LKUser.Visibility = Visibility.Visible;
                Exit.Visibility = Visibility.Visible;
            }
        }

        private void LKUser_Click(object sender, RoutedEventArgs e)
        {
            UserProfil userProfil = new UserProfil();
            userProfil.Show();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void services_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (Title == "User")
            {
                var itemControl = sender as ListBox;
                var btn = itemControl.SelectedItem as Service;

                ClientRecord clientRecord = new ClientRecord(btn);
                var client = clientRecord.ShowDialog();
            }
        }

        private void SortFilter()
        {
            lists.Clear();
            var Filter = fullList.Where(x => x.Name.ToLower().Contains(StrokaPoiska.Text.ToLower()));

            switch (DiscountFilter1.SelectedIndex)
            {
                case 0:
                    Filter = Filter.Where(x => x.Discount >= 0 && x.Discount < 5);
                    break;
                case 1:
                    Filter = Filter.Where(x => x.Discount >= 5 && x.Discount < 15);
                    break;
                case 2:
                    Filter = Filter.Where(x => x.Discount >= 15 && x.Discount < 30);
                    break;
                case 3:
                    Filter = Filter.Where(x => x.Discount >= 30 && x.Discount < 70);
                    break;
                case 4:
                    Filter = Filter.Where(x => x.Discount >= 70 && x.Discount < 100);
                    break;
            }
            switch (DiscountFilter2.SelectedIndex)
            {
                case 0:
                    Filter = Filter.OrderBy(x => x.PriceDiscount);
                    break;
                case 1:
                    Filter = Filter.OrderByDescending(x => x.PriceDiscount);
                    break;
                case 2:
                    Filter = Filter.OrderBy(x => x.Discount);
                    break;
                case 3:
                    Filter = Filter.OrderByDescending(x => x.Discount);
                    break;
            }
            foreach (var item in Filter)
            {
                lists.Add(item);
            }
        }

        private void DiscountFilter2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortFilter();
        }

        private void DiscountFilter1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortFilter();
        }

        private void StrokaPoiska_TextChanged(object sender, TextChangedEventArgs e)
        {
            SortFilter();
        }

        private void EditCost_Click(object sender, RoutedEventArgs e)
        {
            var btn = (e.Source as Button).DataContext as Service;

            EditService editSevice = new EditService(btn);
            var edit = editSevice.ShowDialog();

            if (edit == true)
            {
                InitializeComponent();
                fullList = context.Services.ToList();
                lists = new ObservableCollection<Service>(fullList);
                services.ItemsSource = lists;

                fullList = context.Services.ToList();
                lists.Clear();
                foreach (var item in fullList)
                {
                    lists.Add(item);
                }
            }
        }

        private void DeleteCost_Click(object sender, RoutedEventArgs e)
        {
            var btn = (e.Source as Button).DataContext as Service;

            EditService editSevice = new EditService(btn);

            MessageBoxResult result = MessageBox.Show("Удалить услугу?", "Сообщение", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result == MessageBoxResult.Yes)
            {
                Service service = (Service)context.Services.Where(x => x.Name == editSevice.ServiceName.Text).FirstOrDefault();

                if (context.ServicesBooking.Any(x => x.ServiceId == service.Id))
                {
                    MessageBox.Show("Нельзя удалить услугу, если на нее есть запись клиента.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                context.Services.Remove(service);
                context.SaveChanges();

                InitializeComponent();
                fullList = context.Services.ToList();
                lists = new ObservableCollection<Service>(fullList);
                services.ItemsSource = lists;

                result = MessageBox.Show("Услуга удалена!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Admin_Click(object sender, RoutedEventArgs e)
        {
            Admin admin = new Admin();
            admin.Show();
        }

        private void Create_Click(object sender, RoutedEventArgs e)
        {
            var btn = (e.Source as Button).DataContext as Service;

            CreateService createSevice = new CreateService(btn);
            var create = createSevice.ShowDialog();

            if (create == true)
            {
                InitializeComponent();
                fullList = context.Services.ToList();
                lists = new ObservableCollection<Service>(fullList);
                services.ItemsSource = lists;
            }
        }

        
    }
}
