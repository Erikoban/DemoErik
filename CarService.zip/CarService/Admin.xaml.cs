﻿using CarService.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace CarService
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        public static MainContext context = new MainContext();
        public Admin()
        {
            InitializeComponent();

            RefreshData();

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(30);
            timer.Tick += timer_Tick;
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            RefreshData();
        }
        private void RefreshData()
        {
            string format = "dd.MM.yyyy HH:mm";
            var result = (from serviceBooking in context.ServicesBooking
                          join user in context.Users on serviceBooking.UserId equals user.Id
                          join service in context.Services on serviceBooking.ServiceId equals service.Id
                          select new
                          {
                              Service_name = service.Name,
                              DateTime = serviceBooking.DateTime.ToString(format),
                              FullName = user.FirstName + " " + user.Name + " " + user.Patronymic,
                              Email = user.Email,
                              Phone = user.Phone,

                              DateTime1 = serviceBooking.DateTime
                          }).Where(x => x.DateTime1 >= DateTime.Now).OrderBy(x => x.DateTime1).ToList();
            GridAdmin.ItemsSource = result;
        }

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            var sb = new StringBuilder();

            var headers = new string[] { "Service_name", "DateTime", "FullName", "Email", "Phone" };
            sb.AppendLine(string.Join(";", headers));

            var result = (from serviceBooking in context.ServicesBooking
                          join user in context.Users on serviceBooking.UserId equals user.Id
                          join service in context.Services on serviceBooking.ServiceId equals service.Id
                          select new
                          {
                              Service_name = service.Name,
                              DateTime = serviceBooking.DateTime,
                              FullName = user.FirstName + " " + user.Name + " " + user.Patronymic,
                              Email = user.Email,
                              Phone = user.Phone

                          }).OrderBy(x => x.DateTime).ToList();

            foreach (var item in result)
            {
                var values = headers.Select(header => item.GetType().GetProperty(header).GetValue(item, null))
                                    .Select(value => value == null ? "" : value.ToString())
                                    .ToArray();

                sb.AppendLine(string.Join(";", values));
            }

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string fileName = System.IO.Path.Combine(desktopPath, "export_" + DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss") + ".csv");
            File.WriteAllText(fileName, sb.ToString(), Encoding.UTF8);

            MessageBox.Show("Файл сохранён на рабочий стол!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
